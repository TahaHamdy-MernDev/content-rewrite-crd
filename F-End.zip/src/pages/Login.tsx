import Login from "../components/Auth/Login";


const LoginPage: React.FC = () => {

    return (
        <Login />
    );
};

export default LoginPage;
